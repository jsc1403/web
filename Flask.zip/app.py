import os
import time
import cv2
import numpy as np
import matplotlib.pyplot as plt
from flask import Flask, render_template, request
from pyngrok import conf, ngrok

app = Flask(__name__)


# Ngrok
conf.get_default().region = "jp"
conf.get_default().auth_token = "2Ht4yYFbzjExl53SZzYq8xzTG3c_6z1GUxidyU6gqV3XXkwHc"
http_tunnel = ngrok.connect(5000)
tunnels = ngrok.get_tunnels()

for kk in tunnels:
    print(kk)

@app.route('/')
def render_file():
   return render_template('index.html')


@app.route('/fileUpload', methods = ['GET', 'POST'])
def result():
  
   
    classes = ["Pyoderma", "ringworm", "Homologous bacteria", "motorcycle",
            "airplane", "bus", "train", "truck", "boat", "traffic light", "fire hydrant",
            "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse",
            "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack",
            "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis",
            "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard",
            "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork", "knife",
            "spoon", "bowl", "banana", "apple", "sandwich", "orange", "broccoli", "carrot", "hot dog",
            "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed", "dining table",
            "toilet", "tv", "laptop", "mouse", "remote", "keyboard",
            "cell phone", "microwave", "oven", "toaster", "sink", "refrigerator",
            "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush" ]
    len(classes)

    net = cv2.dnn.readNet("yolov4-custom_best.weights", "yolov4-custom.cfg")

    layer_names = net.getLayerNames()
    output_layers = [layer_names[i - 1] for i in net.getUnconnectedOutLayers()]
    colors = np.random.uniform(0, 255, size=(len(classes), 3))

    f = request.files['file']
    #저장할 경로 + 파일명
    save_to = f'C:/Users/jsj32/Flask/test.jpg'
    f.save(save_to)


    img = cv2.imread("test.jpg")
    height, width, channels = img.shape

    blob = cv2.dnn.blobFromImage(img, 0.00392, (416, 416), (0, 0, 0), True, crop=False)
    net.setInput(blob)
    outs = net.forward(output_layers)

    class_ids = []
    confidences = []
    boxes = []

    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.1:
                # Object detected
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)

                # Rectangle coordinates
                x = int(center_x - w / 2)
                y = int(center_y - h / 2)

                boxes.append([x, y, w, h])
                confidences.append(float(confidence))
                class_ids.append(class_id)

    indexes = cv2.dnn.NMSBoxes(boxes, confidences, 0.1, 0.4)

    font = cv2.FONT_HERSHEY_PLAIN
    for i in range(len(boxes)):
        if i in indexes:
            x, y, w, h = boxes[i]
            label = str(classes[class_ids[i]])
            color = colors[i]
            cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
            cv2.putText(img, label, (x, y - 10), font, 1, color, 2)
            print(label,confidences[i],x,y,w,h)

    #cv2.imshow("Image", img)
    cv2.imwrite("C:\\Users\\jsj32\\Flask\\static\\img\\test.jpg",img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    if(label == "ringworm"):
        return render_template('upload.html')
    
    else:
        return render_template('index.html')


    
if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)