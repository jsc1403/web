from flask import Flask, render_template, request

app = Flask(__name__)
 
#업로드 HTML 렌더링
@app.route('/upload')
def render_file():
   return render_template('upload.html')
 
#파일 업로드 처리
@app.route('/fileUpload', methods = ['GET', 'POST'])
def upload_file():
   #if request.method == 'POST':
   f = request.files['file']
   #저장할 경로 + 파일명
   save_to = f'static/img/user_id2.jpg'
   f.save(save_to)
   return 'uploads 디렉토리 -> 파일 업로드 성공!'
 
if __name__ == '__main__':
    app.run(debug = True, host = '127.0.0.1', port = 5000)